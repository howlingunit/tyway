﻿Imports System.Net.NetworkInformation
Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'timer
        Timer.Start()
    End Sub

    Private Sub Timer_Tick(sender As Object, e As EventArgs) Handles Timer.Tick
        'if else ping code
        If My.Computer.Network.Ping("8.8.8.8") Then
            GDnsB.BackColor = Color.Green
        Else
            GDnsB.BackColor = Color.Red
        End If
        If My.Computer.Network.Ping("192.168.0.1") Then
            RB.BackColor = Color.Green
        Else
            RB.BackColor = Color.Red
        End If
        If My.Computer.Network.Ping("192.168.0.100") Then
            TwB.BackColor = Color.Green
        Else
            TwB.BackColor = Color.Red
        End If
        If My.Computer.Network.Ping("192.168.0.101") Then
            MLPMB.BackColor = Color.Green
        Else
            MLPMB.BackColor = Color.Red
        End If
    End Sub
End Class
'code created by Tyler Pitt
'rev 1.0 created on 15/09/2019
'revision 1.0
'Dont steal my stuff