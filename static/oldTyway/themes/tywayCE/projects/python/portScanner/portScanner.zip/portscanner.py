from os import system
import socket
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
target = input('[+] enter target IP: ')
def scanner(port):
    try:
        sock.connect((target,port))
        return True
    except:
        return False
for portnumber in range (1,9100):
    print("Scanning port", portnumber)
    if scanner(portnumber):
        print ('[*] port', portnumber, '/port','is open')
system("pause;")

