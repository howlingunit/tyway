print("Enter number of credits:")
numCredits = int(input(">"))
print("Enter UCAS points required:")
ucasPoints = int(input(">"))
print ("Enter predicted UCAS points")
predictedPoints = int(input(">"))
if numCredits >= ucasPoints:
    print("Congratulations")
    print ("you can go to uni")
else:
    ("you need to work harder")
    