#!/bin/bash
echo "what folder/file (automatic: C:\Users\repository\repository\)"
read from
echo where to
read to
echo ok
scp -r repository@82.16.37.5:/Users/repository/repository/$from $to
echo $from 
echo $to
