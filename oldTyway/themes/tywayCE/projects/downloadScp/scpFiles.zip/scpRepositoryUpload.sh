#!/bin/bash
echo what dir:
read loc
scp -r $loc repository@82.16.37.5:/users/repository/repository
echo done
