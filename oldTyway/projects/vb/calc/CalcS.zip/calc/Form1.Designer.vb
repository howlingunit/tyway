﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtNum1 = New System.Windows.Forms.TextBox()
        Me.ans = New System.Windows.Forms.TextBox()
        Me.txtNum2 = New System.Windows.Forms.TextBox()
        Me.add = New System.Windows.Forms.Button()
        Me.BtnDiv = New System.Windows.Forms.Button()
        Me.BtnTim = New System.Windows.Forms.Button()
        Me.BtnSub = New System.Windows.Forms.Button()
        Me.ext = New System.Windows.Forms.Button()
        Me.square = New System.Windows.Forms.Button()
        Me.sqrtbtn = New System.Windows.Forms.Button()
        Me.integerbtn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(0, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(74, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "input number1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(0, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "input number2"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(0, 140)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "answer"
        '
        'txtNum1
        '
        Me.txtNum1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtNum1.ForeColor = System.Drawing.SystemColors.Control
        Me.txtNum1.Location = New System.Drawing.Point(3, 25)
        Me.txtNum1.Name = "txtNum1"
        Me.txtNum1.Size = New System.Drawing.Size(71, 20)
        Me.txtNum1.TabIndex = 3
        Me.txtNum1.Text = "0"
        '
        'ans
        '
        Me.ans.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ans.ForeColor = System.Drawing.SystemColors.Control
        Me.ans.Location = New System.Drawing.Point(3, 156)
        Me.ans.Name = "ans"
        Me.ans.ReadOnly = True
        Me.ans.Size = New System.Drawing.Size(71, 20)
        Me.ans.TabIndex = 4
        '
        'txtNum2
        '
        Me.txtNum2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtNum2.ForeColor = System.Drawing.SystemColors.Control
        Me.txtNum2.Location = New System.Drawing.Point(3, 89)
        Me.txtNum2.Name = "txtNum2"
        Me.txtNum2.Size = New System.Drawing.Size(71, 20)
        Me.txtNum2.TabIndex = 5
        Me.txtNum2.Text = "0"
        '
        'add
        '
        Me.add.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.add.Location = New System.Drawing.Point(95, 27)
        Me.add.Name = "add"
        Me.add.Size = New System.Drawing.Size(36, 28)
        Me.add.TabIndex = 6
        Me.add.Text = "+"
        Me.add.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.add.UseVisualStyleBackColor = False
        '
        'BtnDiv
        '
        Me.BtnDiv.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.BtnDiv.Location = New System.Drawing.Point(95, 118)
        Me.BtnDiv.Name = "BtnDiv"
        Me.BtnDiv.Size = New System.Drawing.Size(36, 28)
        Me.BtnDiv.TabIndex = 7
        Me.BtnDiv.Text = "/"
        Me.BtnDiv.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.BtnDiv.UseVisualStyleBackColor = False
        '
        'BtnTim
        '
        Me.BtnTim.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.BtnTim.Location = New System.Drawing.Point(95, 89)
        Me.BtnTim.Name = "BtnTim"
        Me.BtnTim.Size = New System.Drawing.Size(36, 28)
        Me.BtnTim.TabIndex = 8
        Me.BtnTim.Text = "*"
        Me.BtnTim.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.BtnTim.UseVisualStyleBackColor = False
        '
        'BtnSub
        '
        Me.BtnSub.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.BtnSub.Location = New System.Drawing.Point(95, 56)
        Me.BtnSub.Name = "BtnSub"
        Me.BtnSub.Size = New System.Drawing.Size(36, 28)
        Me.BtnSub.TabIndex = 9
        Me.BtnSub.Text = "-"
        Me.BtnSub.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.BtnSub.UseVisualStyleBackColor = False
        '
        'ext
        '
        Me.ext.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ext.Location = New System.Drawing.Point(-1, 199)
        Me.ext.Name = "ext"
        Me.ext.Size = New System.Drawing.Size(75, 23)
        Me.ext.TabIndex = 11
        Me.ext.Text = "exit"
        Me.ext.UseVisualStyleBackColor = False
        '
        'square
        '
        Me.square.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.square.Location = New System.Drawing.Point(95, 152)
        Me.square.Name = "square"
        Me.square.Size = New System.Drawing.Size(36, 28)
        Me.square.TabIndex = 12
        Me.square.Text = "1^2"
        Me.square.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.square.UseVisualStyleBackColor = False
        '
        'sqrtbtn
        '
        Me.sqrtbtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.sqrtbtn.Location = New System.Drawing.Point(95, 186)
        Me.sqrtbtn.Name = "sqrtbtn"
        Me.sqrtbtn.Size = New System.Drawing.Size(36, 28)
        Me.sqrtbtn.TabIndex = 13
        Me.sqrtbtn.Text = "sqrt"
        Me.sqrtbtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.sqrtbtn.UseVisualStyleBackColor = False
        '
        'integerbtn
        '
        Me.integerbtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.integerbtn.Location = New System.Drawing.Point(137, 27)
        Me.integerbtn.Name = "integerbtn"
        Me.integerbtn.Size = New System.Drawing.Size(36, 28)
        Me.integerbtn.TabIndex = 14
        Me.integerbtn.Text = "\"
        Me.integerbtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.integerbtn.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ClientSize = New System.Drawing.Size(211, 220)
        Me.Controls.Add(Me.integerbtn)
        Me.Controls.Add(Me.sqrtbtn)
        Me.Controls.Add(Me.square)
        Me.Controls.Add(Me.ext)
        Me.Controls.Add(Me.BtnSub)
        Me.Controls.Add(Me.BtnTim)
        Me.Controls.Add(Me.BtnDiv)
        Me.Controls.Add(Me.add)
        Me.Controls.Add(Me.txtNum2)
        Me.Controls.Add(Me.ans)
        Me.Controls.Add(Me.txtNum1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.ForeColor = System.Drawing.SystemColors.Control
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtNum1 As TextBox
    Friend WithEvents ans As TextBox
    Friend WithEvents txtNum2 As TextBox
    Friend WithEvents add As Button
    Friend WithEvents BtnDiv As Button
    Friend WithEvents BtnTim As Button
    Friend WithEvents BtnSub As Button
    Friend WithEvents ext As Button
    Friend WithEvents square As Button
    Friend WithEvents sqrtbtn As Button
    Friend WithEvents integerbtn As Button
End Class
