﻿Public Class Form1
    Private Sub add_Click(sender As Object, e As EventArgs) Handles add.Click
        'add
        If IsNumeric(txtNum1.Text) = True And IsNumeric(txtNum2.Text) = True Then
            ans.Text = CDec(txtNum1.Text) + CDec(txtNum2.Text)
        Else
            MessageBox.Show("error 1" & vbCrLf & "please enter numbers")
        End If
    End Sub

    Private Sub BtnSub_Click(sender As Object, e As EventArgs) Handles BtnSub.Click
        'sub
        If IsNumeric(txtNum1.Text) = True And IsNumeric(txtNum2.Text) = True Then
            ans.Text = CDec(txtNum1.Text) - CDec(txtNum2.Text)
        Else
            MessageBox.Show("error 1" & vbCrLf & "please enter numbers")
        End If
    End Sub

    Private Sub BtnTim_Click(sender As Object, e As EventArgs) Handles BtnTim.Click
        'times
        If IsNumeric(txtNum1.Text) = True And IsNumeric(txtNum2.Text) = True Then
            ans.Text = CDec(txtNum1.Text) * CDec(txtNum2.Text)
        Else
            MessageBox.Show("error 1" & vbCrLf & "please enter numbers")
        End If
    End Sub

    Private Sub BtnDiv_Click(sender As Object, e As EventArgs) Handles BtnDiv.Click
        'dev
        If IsNumeric(txtNum1.Text) = True And IsNumeric(txtNum2.Text) = True Then
            ans.Text = CDec(txtNum1.Text) / CDec(txtNum2.Text)
        Else
            MessageBox.Show("error 1" & vbCrLf & "please enter numbers")
        End If
    End Sub

    Private Sub ext_Click(sender As Object, e As EventArgs) Handles ext.Click
        'close
        MessageBox.Show("goodbye")
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles square.Click
        '^2
        If IsNumeric(txtNum1.Text) = True Then
            ans.Text = CDec(txtNum1.Text) ^ 2
        Else
            MessageBox.Show("error 1" & vbCrLf & "please enter numbers")
        End If
    End Sub

    Private Sub sqrtbtn_Click(sender As Object, e As EventArgs) Handles sqrtbtn.Click
        If IsNumeric(txtNum1.Text) = True Then
            ans.Text = Math.Sqrt(CDec(txtNum1.Text))
        Else
            MessageBox.Show("error 1" & vbCrLf & "please enter numbers")
        End If
    End Sub

    Private Sub integerbtn_Click(sender As Object, e As EventArgs) Handles integerbtn.Click
        If IsNumeric(txtNum1.Text) = True And IsNumeric(txtNum2.Text) = True Then
            ans.Text = CDec(txtNum1.Text) \ CDec(txtNum2.Text)
        Else
            MessageBox.Show("error1" & vbCrLf & "please enter numbers")
        End If
    End Sub
End Class
'program made by Tyler Pitt
'program made 11/09/2019
'program updated 13/09/2019
'dont steal my stuff
