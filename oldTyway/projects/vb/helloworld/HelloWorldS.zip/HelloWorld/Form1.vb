﻿Public Class Form1
    Private Sub Button_Click(sender As Object, e As EventArgs) Handles Button.Click
        MessageBox.Show("hello " & vbCrLf & txtInput.Text)
    End Sub

    Private Sub txtInput_TextChanged(sender As Object, e As EventArgs) Handles txtInput.TextChanged
    End Sub

    Private Sub ext_Click(sender As Object, e As EventArgs) Handles ext.Click
        MessageBox.Show("goodbye " & txtInput.Text)
        Me.Close()
    End Sub

    Private Sub Button_MouseWheel(sender As Object, e As MouseEventArgs) Handles Button.MouseWheel
        MessageBox.Show("hidden " & txtInput.Text)
    End Sub
End Class
'code made by Tyler Pitt
'made on 11/09/2019
'dont steal my stuff!!
'22804434453389
