import random
import time
import os
import datetime
#vars =======================================================================================================================================================================================================================
pBoard = ['~~'] * 17                     
cBoard = ['~~'] * 17

Phits = 0
Pmisses = 0

Chits = 0
Cmisses = 0
#============================================================================================================================================================================================================================
  
#board stuff ================================================================================================================================================================================================================================
def testBoards(): #just to use when testing the program
    drawboard(cBoard, "computer", Chits, Cmisses)
    drawboard(pBoard, "player", Phits, Pmisses)

def drawboard(board, who, hits, misses):
    print("this is the board of " + who)
    print("you have ", hits, " hits")
    print("you have ", misses, " misses")
    
    print('---------------')
    print('    |    |    |')
    print(' ' + board[7] + ' | ' + board[8] + ' | ' + board[9] +' | ')
    print('    |    |    |')
    print('---------------')
    print('    |    |    |')
    print(' ' + board[4] + ' | ' + board[5] + ' | ' + board[6] +' | ')
    print('    |    |    |')
    print('---------------')
    print('    |    |    |')
    print(' ' + board[1] + ' | ' + board[2] + ' | ' + board[3] +' | ')
    print('    |    |    |')
    print('---------------')
#=============================================================================================================================================================================================================================================

#computer and player stuff =======================================================================================================================================================================================================================
#Classes==================================================================================================================================================================================================================================================================================
class ArrFind: #class to check though an array to find a cirtan amount of a value 
    def __init__(self, array, SearchNum, Amount):
        self.array = array
        self.SearchNum = SearchNum
        self.Amount = Amount

    def main(self):
        x = 0
        for y in self.array:
            if self.SearchNum == y:
                x = x + 1

        if x >= self.Amount:
            return "True"
        else:
            return "false"
#====================================================================================================================================================================================================================================================================================================



def whoGoesFirst():
    if random.randint(0, 1) == 0:
        return "computer"
    else:
        return "human"

def PlaceShip(location, whichboard):
    whichboard[location] = ' S'

def clear():
    os.system("cls")

#win stuff=====================================================================================================================================================================================================================================================================================
def Twin(player, board): #function to test if a side has won
    isWin = ArrFind(board, " H", 3).main()
    if isWin == "True":
        Win(player)

def Win(Player): #this is what happens when you win
    print(Player, " has won!!!")
    file(Player)
    again()

def again():
    print("do you want to go again(Y/N)")
    print("or do you want to view th log(L)")
    print("note: must be caps")
    a = input(">")
    if a == "Y":
        print("staring again")
        clear()
        main()
    elif a =="L":
        os.system("wins.txt")
    else:
        print("goodbye thanks for playing!!")
        exit()

def file(player): #the def to write the log file 
    CurrentTime = datetime.datetime.now()
    file = open("wins.txt", "a")
    file.write('\n')
    file.write('\n')#empty spaces
    file.write('Game won by '+player+' on:')
    file.write('\n')
    file.write("%d" %CurrentTime.day)
    file.write('/')
    file.write("%d" %CurrentTime.month)
    file.write('/')
    file.write("%d" %CurrentTime.year)
    file.write('\n')
    file.write('at:')
    file.write('\n')
    file.write("%d" %CurrentTime.hour)
    file.write(":")
    file.write("%d" %CurrentTime.minute)
#=======================================================================================================================================================================================================================================================================================
#=========================================================================================================================================================================================================================================================

#player stuff ==============================================================================================================================================================================================================================================================
def placePlayerShips(board, who):
    for i in range(3):#this is use of iteration, it has a loop that people can input into
        #drawboard(board, who, hits, misses)
        print("now you must place your ships on your board")
        print("enter a grid coordinate (1 is bottom left and 9 is top right)")
        GL= int(input(">"))
        while GL > 0 and GL < 10:#validation to make sure the number is in between 0 and 10
            PlaceShip(GL, board)
            GL = 0


def Pturn(board):
    print("player turn")
    drawboard(pBoard, "player", Phits, Pmisses)
    #testBoards()
    print("enter grid coordinate that you want to try and hit (1 is bottom left and 9 is top right)")
    GL = int(input(">"))
    while GL > 0 and GL < 10:
        PhitShip(GL, cBoard)
        GL = 0
    Twin("player", cBoard)
    Cturn(pBoard)
    
def PhitShip(location, whichboard):
    global Phits #simple sequence for hitting/missing a ship
    global Pmisses
    if whichboard[location] == ' S':
        whichboard[location] = ' H'
        Phits += 1
        print("******************")
        print("*you hit a ship!!*")
        print("******************")
        time.sleep(2)
    else:
        Pmisses += 1
#=====================================================================================================================================================================================================================================================================================

#computer stuff =================================================================================================================================================================================================================================================================
def Cturn(board):
    print("computer turn")
    for i in range(2):
        print("...")
        time.sleep(0.5)
    GL = random.randint(1, 9)
    #generates a random number in the grid to fire at
    ChitShip(GL, pBoard)
    Twin("computer", pBoard)
    print("computer turn done")
    Pturn(pBoard)

def placeComputerShips():
    for i in range(3):
        x = random.randint(1, 9)
        PlaceShip(x, cBoard)
    TestShips(cBoard) #this is to make sure that the computer has placed three ships

def TestShips(Board):
    IsGood = ArrFind(Board, " S", 3).main()
    if IsGood == "false":
        global cBoard
        cBoard = ['~~'] * 17
        placeComputerShips() #if there are less than three ships it runs place ships again

def ChitShip(location, whichboard):
    global Chits
    global Cmisses
    if whichboard[location] == ' S':
        whichboard[location] = ' H'
        Chits += 1
        print("*********************")
        print("*computer hit you!!!*")
        print("*********************")
        time.sleep(2)
    else:
        Cmisses += 1
#=================================================================================================================================================================================================================================================================================

#main def===========================================================================================================================================================================================================================================================================
def main(): #the main function that follows a sequence and then goes into a selection
    print("*************************")
    print("*welcome to battle ships*")
    print("*************************")
    global cBoard
    global pBoard
    pBoard = ['~~'] * 17                     
    cBoard = ['~~'] * 17
    for i in range(3):
        print("...")
        time.sleep(0.5)
    y = whoGoesFirst()
    #y = "human"
    print("this is your board:")
    drawboard(pBoard, "player", Phits, Pmisses)
    time.sleep(3)
    placePlayerShips(pBoard, "player")
    drawboard(pBoard, "player", Phits, Pmisses)
    placeComputerShips()
    print("placing computer ships")
    for i in range(3):
        print("...")
        time.sleep(0.5)
    print("computer ships placed")
    if y == "human": # this is a selection of picking who goes first
        print("you go first")
        time.sleep(1)
        Pturn(pBoard)
    else:
        print("computer goes first")
        time.sleep(3)
        Cturn(cBoard)
#======================================================================================================================================================================================================================================================================================

main()