import socket

headerSize = 10
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(('192.168.0.102', 1234))

#prss
Phead = s.recv(headerSize)
Plen = int(Phead.decode("utf-8"))
P = s.recv(Plen).decode("utf-8")
#temp
Thead = s.recv(headerSize)
Tlen = int(Thead.decode("utf-8"))
T = s.recv(Tlen).decode("utf-8")
#humid
Hhead = s.recv(headerSize)
Hlen = int(Hhead.decode("utf-8"))
H = s.recv(Hlen).decode("utf-8")
s.close()
print(f"press:{P}")
print(f"temp:{T}")
print(f"humid:{H}")