import socket
import time
headerSize = 10

print("please input IP")
IP = str(input(">"))

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((IP, 1234))


while True:
    #prss
    Phead = s.recv(headerSize)
    Plen = int(Phead.decode("utf-8"))
    P = s.recv(Plen).decode("utf-8")
    #temp
    Thead = s.recv(headerSize)
    Tlen = int(Thead.decode("utf-8"))
    T = s.recv(Tlen).decode("utf-8")
    #humid
    Hhead = s.recv(headerSize)
    Hlen = int(Hhead.decode("utf-8"))
    H = s.recv(Hlen).decode("utf-8")

    print(f"pressure:{P}")
    print(f"temp:{T}")
    print(f"humid:{H}")
    time.sleep(1)
