from sense_hat import SenseHat
import time

sense = SenseHat()
sense.clear()
try:
    while True:
        temp = sense.get_temperature()
        temp = temp - 9.5
        temp = round(temp, 2)
        print(temp)
        time.sleep(1)
except(KeyboardInterrupt):
    print("goodbye!!")