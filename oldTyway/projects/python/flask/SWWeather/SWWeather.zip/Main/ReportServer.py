import socket
import time
from sense_hat import SenseHat

sense = SenseHat()

HeaderLength = 10
#IP = "127.0.0.1" 
Port = 1234

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

server_socket.bind(('192.168.0.102', Port))
server_socket.listen()

week=[]
avgTweek = []

# def avgWeek():
	# week = week.append(round(sense.get_temperature()))

    

while True:
    try:
        clientsocket, address = server_socket.accept()
        print(f"connection from {address}") 
        while True:
            # schedule.every.day.at("14:30").do(avgWeek())
            p = sense.get_pressure()
            t = sense.get_temperature() - 10
            h = sense.get_humidity()
            # p = 10
            # t = 20
            # h = 30
            p = str(p).encode("utf-8")
            t = str(t).encode("utf-8")
            h = str(h).encode("utf-8")
            PmsgHead = f'{len(p):<{HeaderLength}}'.encode("utf-8")
            TmsgHead = f'{len(t):<{HeaderLength}}'.encode("utf-8")
            HmsgHead = f'{len(h):<{HeaderLength}}'.encode("utf-8")
            clientsocket.send(PmsgHead + p)
            clientsocket.send(TmsgHead + t)
            clientsocket.send(HmsgHead + h)
            p= 0
            t= 0
            h= 0
    except socket.error:
        continue