from flask import Flask, render_template
import socket
# from sense_hat import SenseHat
app = Flask(__name__)

def getinfo():
    headerSize = 10
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(('192.168.0.102', 1234))

    #prss
    Phead = s.recv(headerSize)
    Plen = int(Phead.decode("utf-8"))
    P = s.recv(Plen).decode("utf-8")
    #temp
    Thead = s.recv(headerSize)
    Tlen = int(Thead.decode("utf-8"))
    T = s.recv(Tlen).decode("utf-8")
    #humid
    Hhead = s.recv(headerSize)
    Hlen = int(Hhead.decode("utf-8"))
    H = s.recv(Hlen).decode("utf-8")
    s.close()

    # P = sense.get_pressure()
    # T = sense.get_temperature() - 10
    # H = sense.get_humidity()

    return P, T, H

@app.route("/")
@app.route("/main")
def home():
    P, T, H = getinfo()
    T = round(float(T), 1)
    return render_template("SWWeather.html", title="star wars weather", T=T)

@app.route("/about")
def about():
    return render_template("about.html",title="about")

@app.route("/raw")
def SSWeather():
    P, T, H = getinfo()
    return render_template("raw.html",title="raw data", P=P, T=T, H=H)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80)