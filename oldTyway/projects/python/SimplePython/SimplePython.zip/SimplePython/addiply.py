masterArr = []
print("input number of test cases")
t = int(input(">"))
for i in range(t):
    nums = input(">")
    arrnum = nums.split(" ")
    arrnum = [int(x) for x in arrnum]
    add = arrnum[0]+arrnum[1]
    mul = arrnum[0]*arrnum[1]
    temparr = [add, mul]
    masterArr.append(temparr)

for a in masterArr:
    print(a)

    