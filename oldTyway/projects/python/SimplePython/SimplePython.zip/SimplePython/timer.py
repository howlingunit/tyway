import time
import os
print("welcome to this simple timer")
print("****************************")

def sec():
    print("please input time")
    t = int(input(">"))
    x = t
    for i in range(t):
        time.sleep(1)
        x=x - 1
        print(x, "seconds left")
    os.system("start " + "Ring01.wav")


def min():
    print("please input time")
    t = int(input(">"))
    x = t
    for i in range(t):
        time.sleep(60)
        x=x - 1
        print(x, "mins left")
    os.system("start " + "Ring01.wav")

def hour():
    print("please input time")
    t = int(input(">"))
    x = t
    for i in range(t):
        time.sleep(3600)
        x=x - 1
        print(x, "hours left")
    os.system("start " + "Ring01.wav")

def main():
    while True:
        print("what unit of time? seconds(s) minutes(m) hours(h) exit(e)")
        u = input(">")
        if u == "s":
            sec()
        elif u == "m":
            min()
        elif u == "h":
            hour()
        elif u == "e":
            exit()
        else:
            print("error")


main()