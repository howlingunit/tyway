print("welcome to my echo program")
print("how many lines")
echo = []
lines = int(input(">"))
for i in range (lines):
    x = str(input(">"))
    echo.append(x)
    echo.append(x)

for a in echo:
    print(a)

