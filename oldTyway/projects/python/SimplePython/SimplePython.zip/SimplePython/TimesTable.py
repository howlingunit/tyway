print("input number for its times table")
n = int(input(">"))
print("input range")
r = int(input(">"))
num=1
while num <= r:
    print (n * num)
    num=num+1
