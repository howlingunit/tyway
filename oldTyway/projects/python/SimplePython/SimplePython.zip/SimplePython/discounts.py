print ("please input your name:")
name = input(">")
print ("hello " + name)
OriginalPriceString = input("Enter the price if the item: ")
OriginalPrice = float(OriginalPriceString)
salepricestring = input("enter the sale price ")
saleprice = float(salepricestring)
percentoff = (OriginalPrice - saleprice) / OriginalPrice * 100
print("Original price: $%.2f" %OriginalPrice)
print("sale saleprice: $%.2f" %saleprice)
print("percent off: %2d" %percentoff + "%")
if percentoff >= 15:
    print("you got a great sale " + name)
else:
    print("dont go for it!!!!")
