import time

print("loading")
for i in range(5):
    print("...")
    time.sleep(0.5)

#vars
f = open("IlikeCheese.txt", "a")
t=0

print("welcome to the i like cheese creator")
print("************************************")
while True:
    f.write("I like cheese ")
    print("")
    t=t+1
    print(t)