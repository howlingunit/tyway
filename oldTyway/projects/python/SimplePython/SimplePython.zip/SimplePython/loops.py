import time
print ("please enter your name")
name = input(">")
x = 0
while x <= (25) :
    print (name)
    time.sleep(0.2)
    x=x+1
    print (x)
