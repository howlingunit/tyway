def add(x, y):
    z = x+y
    return z
def sub(x, y):
    z = x-y
    return z
def dev(x, y):
    z = x+y
    return z
def mul(x, y):
    z = x+y
    return z

def again():
    print("do you want to go again?")
    a = input(">")
    if a == "Y":
        main()
    elif a == "y":
        main()
    else:
        exit()

def main():
    print("welcome to a simple calculator")
    print("input num1:")
    num1 = float(input(">"))
    print("input num2:")
    num2 = float(input(">"))
    print("input operation a(add) s(sub) d(dev) m(mul)")
    while True:
        o = input(">")
        if o == "a":
            x=add(num1, num2)
            print("answare is ", x)
            again()
        elif o == "s":
            x=sub(num1, num2)
            print("answare is ", x)
            again()
        elif o == "d":
            x=dev(num1, num2)
            print("answare is ", x)
            again()
        elif o == "m":
            x=mul(num1, num2)
            print("answare is ", x)
            again()
        else:
            print("error")

main()