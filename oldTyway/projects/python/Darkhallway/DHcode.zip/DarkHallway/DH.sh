#!/bin/bash
session="DarkHallway"
tmux new-session -d -s IO
tmux rename-window -t 0 IO
tmux send-keys -t IO:0 'cd DarkHallway/Scripts/' C-m 'python3 clientOutput.py' C-m


tmux split-window -v -t IO
tmux send-keys -t IO 'cd DarkHallway/Scripts/' C-m  'python3 clientInput.py' C-m
tmux -2 attach-session -d
